# **Exercise:** [New Exercise]

Using what you have learned so far in this chapter, work through the exercise on exploratory data analysis by launching the code notebook below. 

<a href="https://colab.research.google.com/drive/1WDhino5fdeq68OdLLN5ocrYVhCuA3ZLU?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise!</a>

After our class session, launch the finisher notebook below to see the answers to the explortory data analysis exercise.

```{warning}
You will not have access to the finisher notebook until after the relevant class session.
```

<a href="https://colab.research.google.com/drive/1WDhino5fdeq68OdLLN5ocrYVhCuA3ZLU?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise Answers!</a>