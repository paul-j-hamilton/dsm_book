# **Quiz**

```{note}
All quizzes are graded based on completion, not accuracy.
```

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdsgRM19TWz4hlH9AtAK9wkpqpo-qYp7Bbc5XgEPyCi-murCg/viewform?embedded=true" width="800" height="2421" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>