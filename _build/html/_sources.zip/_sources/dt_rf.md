# Tree Models

In this chapter we will learn about tree models, a class of machine learning algorithms that make predictions based on one or more decision trees fit to the training data.

(See [here](knn.html#k-nearest-neighbors-knn) for a brief description of the churn data that we will use in this chapter.)