# **Quiz**

```{note}
All quizzes are graded based on completion, not accuracy.
```

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLScwUltskKi7XBhdJCfqQvgS8qoOzGn29jXu7zHIOmtmRZyXqw/viewform?embedded=true" width="800" height="382" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>