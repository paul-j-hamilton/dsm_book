
# **Exercise:** Data Frame Manipulation

<iframe src="https://hbs-data-science.shinyapps.io/df_manipulation/" width="1000" height="800" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>

