# **Quiz**

```{note}
All quizzes are graded based on completion, not accuracy.
```
<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSch7jSbqxhdV0T8BPXobRfZHOPbgPIs3VZbh9gEdQal7rRc8Q/viewform?embedded=true" width="800" height="2686" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>