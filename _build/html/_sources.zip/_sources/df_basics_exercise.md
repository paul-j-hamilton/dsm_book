
# **Exercise:** Data Frame Basics

<iframe src="https://hbs-data-science.shinyapps.io/df_basics/" width="1000" height="800" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>

