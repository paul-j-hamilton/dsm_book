# **Exercise:** Causal Inference

Using what you have learned so far in this chapter, work through the exercise by launching the code notebook below. 

<a href="https://colab.research.google.com/drive/1ODmP8dIV7jdQiEH_7G-MpsVfjfU2mnfb?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise!</a>

After our class session, launch the finisher notebook below to see the answers to the exercise.

```{warning}
You will not have access to the finisher notebook until after the relevant class session.
```

<a href="https://colab.research.google.com/drive/1DohQ5blHJCcXboP0-XrYc8aVJmCf3r7c?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise Answers!</a>