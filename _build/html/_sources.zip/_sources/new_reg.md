# **Case Study:** [New Case]

[Description and link to our new case on regression]

To help prepare the case questions for our class discussion, work through the notebook below.

<a href="https://colab.research.google.com/drive/1WDhino5fdeq68OdLLN5ocrYVhCuA3ZLU?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Notebook!</a>