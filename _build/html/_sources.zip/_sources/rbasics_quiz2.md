# **Quiz #2**

```{note}
All quizzes are graded based on completion, not accuracy.
```

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSfaLdIfRO_5jA7OLVsOrI0X_YNkSl4EdEQKmrXTzrVUAoeylw/viewform?embedded=true" width="800" height="1330" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>