# Class 6: Assignment Sheet

**Before Class**

1. Work through the [*Linear Regression*](linear_regression.html#linear-regression) section of the book, including the embedded exercises and quiz.
	+ Note that you do *not* need to work through the optional sections.
2. Read the [*[New Case]*]() case and work through the accompany notebook below to prepare the analyses for the case.

<a href="https://colab.research.google.com/drive/1WDhino5fdeq68OdLLN5ocrYVhCuA3ZLU?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Notebook!</a>

