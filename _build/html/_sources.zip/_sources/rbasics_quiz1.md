# **Quiz #1**

```{note}
All quizzes are graded based on completion, not accuracy.
```

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSczsJw9A-oxxoGgpAXOnqJb-kkZNiy16jid3CbH1oSc3DFwYA/viewform?embedded=true" width="800" height="1929" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>