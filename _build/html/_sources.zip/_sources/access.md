# Access to Materials

You will need a Google account to access the course materials. You can use a pre-existing account, or create a new one for this course. To create a new account, see <a href="https://accounts.google.com/SignUp?hl=en" target="_blank">here</a>. 

Once you have an account, fill out the poll below. 

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeDotevMamyYp-g3aq2hclAGoLwNxwCwG7wjJIANv7wjRJEdw/viewform?embedded=true" width="800" height="1250" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>