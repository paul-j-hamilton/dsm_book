# **Exercise:** Simple Linear Regression

Using what you have learned so far in this chapter, work through the exercise on simple linear regression by launching the code notebook below. 

<a href="https://colab.research.google.com/drive/1yOcJwVtfbFRkx4Cu8V-Af1enmPhFQUv9?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise!</a>

After our class session on linear regression, launch the finisher notebook below to see the answers to the simple linear regression exercise.

```{warning}
You will not have access to the finisher notebook until after the relevant class session.
```

<a href="https://colab.research.google.com/drive/1oNUrXxWGMgrjh8QCc-gFaSPkVMwmiL0g?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise Answers!</a>