# Data Wrangling with the tidyverse

In this section, we will see some of the advanced functionality for data wrangling offered by the tidyverse.