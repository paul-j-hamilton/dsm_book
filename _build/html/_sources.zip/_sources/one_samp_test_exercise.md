# **Exercise:** One-Sample Hypothesis Testing (&#9909;)

Using what you have learned so far in this chapter, work through the exercise by launching the code notebook below. 

<a href="https://colab.research.google.com/drive/1vNjoVZGf5wwmBLn_YabJasjdJFioy8bU?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise!</a>

After our class session, launch the finisher notebook below to see the answers to the exercise.

```{warning}
You will not have access to the finisher notebook until after the relevant class session.
```

<a href="https://colab.research.google.com/drive/1m-n9Tc9fEVoks-7knk2rTWQa7LrUvMDY?usp=sharing" class="btn btn-primary" style="color:white;" target="_blank">Launch Exercise Answers!</a>